<?php

class ShoppingCart {
  
  public $articles;

  public function __construct() {
    $this->articles = [];
  }

}

?>