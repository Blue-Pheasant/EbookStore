<div class="row">
  <div class="col-lg-6">
    <section class="panel">
      <header class="panel-heading">
      </header>
      <div class="panel-body">
        <a href="https://www.accuweather.com/es/cr/san-pedro/115124/weather-forecast/115124" class="aw-widget-legal"></a>
        <div id="awcc1512538713960" class="aw-widget-current"  data-locationkey="115124" data-unit="c" data-language="es" data-useip="false" data-uid="awcc1512538713960"></div>
        <script type="text/javascript" src="https://oap.accuweather.com/launch.js"></script>
      </div>
    </section>
  </div>
  <div class="col-lg-6">
    <section class="panel">
      <header class="panel-heading">
      </header>
      <div class="panel-body">
        <p class="col-lg-12 text-center">
          Copyright (C) <?=date('Y')?> - <a href="http://kevinrodriguez.io/">kevinrodriguez.io</a> 
        </p>
      </div>
    </section>
  </div>
</div>